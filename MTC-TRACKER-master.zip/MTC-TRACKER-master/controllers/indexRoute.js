exports.IndexGet = (req, res) => {
  res.sendFile('index.html');
};
